package com.viewnext;

import com.viewnext.models.Direccion;
import com.viewnext.models.Empleado;

public class AppMain {

	public static void main(String[] args) {
		
		Direccion dir1 = new Direccion("Mayor", 27, "Madrid");
		Empleado empleado1 = new Empleado(1, "Juan", 52_000, dir1);
		
		Empleado empleado2 = new Empleado(2, "Maria", 62_000, 
				new Direccion("Diagonal", 37, "Barcelona"));
		
		System.out.println(empleado1);
		System.out.println(empleado2);
	}

}
