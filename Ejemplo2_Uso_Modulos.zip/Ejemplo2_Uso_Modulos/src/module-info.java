module com.viewnext.ejemplo2 {
	
	// Para poder usar el modulo de otro proyecto:
	// 1.- agregarlo como dependencia del build path
	// 2.- importarlo con requires
	requires com.viewnext.ejemplo1;
}