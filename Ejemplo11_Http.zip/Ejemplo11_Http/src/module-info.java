module com.viewnext.ejemplo11 {
	
	requires java.net.http;
	
}