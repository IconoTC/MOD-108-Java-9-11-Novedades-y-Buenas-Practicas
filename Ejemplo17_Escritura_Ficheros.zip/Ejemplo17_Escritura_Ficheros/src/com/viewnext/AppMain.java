package com.viewnext;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;

public class AppMain {

	public static void main(String[] args) {
		
		Path path = Paths.get("texto.txt");
		
		try {
			Files.writeString(path, "Hola", StandardOpenOption.APPEND);
			Files.writeString(path, "\n", StandardOpenOption.APPEND);
			Files.writeString(path, "Que tal?", StandardOpenOption.APPEND);
			Files.writeString(path, "\n", StandardOpenOption.APPEND);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
