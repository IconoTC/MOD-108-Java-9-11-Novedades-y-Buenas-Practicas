module com.viewnext.ejercicio3 {
	
	requires java.net.http;
	requires org.json;
}