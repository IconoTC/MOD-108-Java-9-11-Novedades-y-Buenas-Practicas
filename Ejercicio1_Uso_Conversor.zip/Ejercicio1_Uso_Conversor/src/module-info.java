module com.viewnext.ejercicio1.uso {
	
	requires com.viewnext.ejercicio1;
	
}