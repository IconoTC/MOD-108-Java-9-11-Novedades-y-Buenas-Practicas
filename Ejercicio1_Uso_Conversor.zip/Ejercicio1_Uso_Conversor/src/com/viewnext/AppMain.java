package com.viewnext;

import com.viewnext.business.Conversor;

public class AppMain {

	public static void main(String[] args) {
		
		Conversor conversor = new Conversor();
		
		System.out.println("100 euros son " + 
				conversor.euroToDollar(100) + " dolares");
		
		System.out.println("100 dolares son " + 
				conversor.dollarToEuro(100) + " euros");

	}

}
