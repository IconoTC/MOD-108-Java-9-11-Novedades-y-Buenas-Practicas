module com.viewnext.ejemplo6 {
}