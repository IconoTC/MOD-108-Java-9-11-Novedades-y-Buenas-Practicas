package com.viewnext;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

public class AppMain {

	public static void main(String[] args) {
		
		String fichero = "datos.txt";
		Path path = Paths.get(fichero);
		String contenido = null;
		List<String> lineas = null;
		
		try {
			// Leer todo el contenido de una sola vez y lo retorna como String
			contenido = Files.readString(path);
			
			// Leer todo el contenido de una sola vez y lo retorna como lista
			lineas = Files.readAllLines(path);
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(contenido);
		System.out.println("-".repeat(20));
		
		lineas.forEach(System.out::println);

	}

}
