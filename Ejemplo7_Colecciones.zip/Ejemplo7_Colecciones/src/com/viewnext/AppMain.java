package com.viewnext;

import java.util.ArrayList;
import java.util.List;

public class AppMain {

	public static void main(String[] args) {
		
		List<String> nombres = new ArrayList<>();
		nombres.add("Juan");
		nombres.add("Maria");
		nombres.add("Pedro");
		nombres.add(null);
		
		nombres.remove(0);
		System.out.println(nombres);
		
		// Java 9 permite crear listas inmutables
		// como las tuplas en Python
		List<String> nombres2 = List.of("Juan", "Maria", "Pedro");
		
		// Las colecciones inmutables no aceptan valores nulos
		//List<String> nombres2 = List.of("Juan", "Maria", "Pedro", null);
		
		// java.lang.UnsupportedOperationException
		// nombres2.remove(0);
		// nombres2.add("Jorge");
		
		// Las colecciones inmutables se utilizan para valores que no cambian
		List<String> dias = List.of("Lunes", "Martes", "Miercoles", "Jueves", "Viernes", "Sabado", "Domingo");

	}

}
