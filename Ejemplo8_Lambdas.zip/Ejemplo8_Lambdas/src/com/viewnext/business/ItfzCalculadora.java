package com.viewnext.business;

// Es una interface funcional porque solo tiene un metodo abstracto

@FunctionalInterface
public interface ItfzCalculadora {

	double operacion(double n1, double n2);
}
