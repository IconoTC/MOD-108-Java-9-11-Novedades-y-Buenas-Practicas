package com.viewnext.models;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.Scanner;

public class AppMain {

	@SuppressWarnings("resource")
	public static void main(String[] args) {
		
		int id = 0;
		String descripcion = "";
		double precio = 0;
		
		Path path = Paths.get("productos.txt");
		
		for(int i=1; i<=5; i++) {
			Scanner sc = new Scanner(System.in);
			System.out.println("Introduce id: ");
			try {
				id = sc.nextInt();
			} catch (Exception ex) {
				System.out.println("Debe ser numerico, vuelva a intertarlo");
				sc = new Scanner(System.in);
				id = sc.nextInt();
			}
			
			System.out.println("Introduce descripcion: ");
			sc = new Scanner(System.in);
			descripcion = sc.nextLine();
			
			System.out.println("Introduce precio: ");
			sc = new Scanner(System.in);
			try {
				precio = sc.nextDouble();
			}catch (Exception ex) {
				System.out.println("Debe ser numerico, vuelva a intertarlo");
				sc = new Scanner(System.in);
				precio = sc.nextDouble();
			}
			
			Producto producto = new Producto(id, descripcion, precio);
			
			try {
				Files.writeString(path, producto.toString() + "\n", StandardOpenOption.APPEND);
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			sc.close();
		}

	}

}
