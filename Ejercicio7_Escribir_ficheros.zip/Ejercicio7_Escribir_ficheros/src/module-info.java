module com.viewnext.ejercicio7 {
}