module com.viewnext.ejemplo19 {
	
	requires java.desktop;
	
}