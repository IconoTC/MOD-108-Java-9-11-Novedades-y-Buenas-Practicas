module com.viewnext.proveedor {
	
	requires com.viewnext.servicio;
	provides com.viewnext.interfaz.ItfzCalculadora with com.viewnext.business.Calculadora;
}