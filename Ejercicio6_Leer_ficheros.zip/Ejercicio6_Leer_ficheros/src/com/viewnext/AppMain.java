package com.viewnext;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.viewnext.models.Producto;

public class AppMain {

	public static void main(String[] args) {
		
		Path path = Paths.get("productos.txt");
		List<String> lineas = new ArrayList<String>();
		List<Producto> productos = new ArrayList<Producto>();
		
		try {
			lineas = Files.readAllLines(path);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		for(String linea : lineas) {
			// split por -
			String[] datos = linea.split("-");
			
			// Eliminar espacios en blanco
			for(int i=0; i<datos.length; i++) {
				datos[i] = datos[i].strip();
			}
			
			// parsear el id a entero y el precio a double
			int id = Integer.parseInt(datos[0]);
			double precio = Double.parseDouble(datos[2]);
			
			// Crear el objeto producto
			Producto producto = new Producto(id, datos[1], precio);
			
			// Agregamos el producto a la lista
			productos.add(producto);
		}
		
		// Recorrer la lista de productos y mostrarla por consola
		productos.forEach(System.out::println);

	}

}
