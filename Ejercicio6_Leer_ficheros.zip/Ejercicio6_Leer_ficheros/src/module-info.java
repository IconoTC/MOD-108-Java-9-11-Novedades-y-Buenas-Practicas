module com.viewnext.ejercicio6 {
}