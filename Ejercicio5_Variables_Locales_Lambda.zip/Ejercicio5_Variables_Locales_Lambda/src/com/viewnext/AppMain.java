package com.viewnext;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import com.viewnext.models.Alumno;

public class AppMain {

	public static void main(String[] args) {
		
		// Crear un Comparator por nombre utilizando lambdas e inferencia de tipos
		Comparator<Alumno> porNombre = (var alum1, var alum2) -> 
			alum1.getNombre().compareTo(alum2.getNombre());
			
		// Crear un TreeSet aplicando ese comparador
		Set<Alumno> alumnos = new TreeSet<Alumno>(porNombre);
		
		// Agregar 5 alumnos
		alumnos.add(new Alumno(1, "Juan", "Perez", 'H', 7.5, false));
		alumnos.add(new Alumno(2, "Maria", "Sanchez", 'M', 4.2, true));
		alumnos.add(new Alumno(3, "Pedro", "Gonzalez", 'H', 9.2, false));
		alumnos.add(new Alumno(4, "Luis", "Rodriguez", 'H', 8.3, false));
		alumnos.add(new Alumno(5, "Sara", "Garcia", 'M', 10, true));
		
		alumnos.forEach(System.out::println);
		System.out.println("------------");
		
		// Generar una lista a partir del TreeSet
		List<Alumno> lista = new ArrayList<Alumno>(alumnos);
		
		// Utilizando lambdas ordenar la lista por nota ascendente
		lista.sort(Comparator.comparingDouble(Alumno::getNota));
		lista.forEach(System.out::println);
		System.out.println("------------");
		
		// Utilizando lambdas ordenar la lista por nota descendente
		lista.sort(Comparator.comparingDouble(Alumno::getNota).reversed());
		lista.forEach(System.out::println);
		System.out.println("------------");
		
		// Utilizando lambdas ordenar la lista por numAlumno ascendente
		lista.sort( (var alum1, var alum2) -> alum1.getNumAlumno() - alum2.getNumAlumno()  );
		lista.forEach(System.out::println);
		System.out.println("------------");
		
		// Utilizando lambdas ordenar la lista por numAlumno descendente
		lista.sort( (var alum1, var alum2) -> alum2.getNumAlumno() - alum1.getNumAlumno()  );
		lista.forEach(System.out::println);
		System.out.println("------------");
		
		// Utilizando lambdas ordenar la lista por apellido ascendente
		lista.sort( (var alum1, var alum2) -> alum1.getApellido().compareTo(alum2.getApellido()) );
		lista.forEach(System.out::println);
		System.out.println("------------");
		
		// Utilizando lambdas ordenar la lista por apellido descendente
		lista.sort( (var alum1, var alum2) -> alum2.getApellido().compareTo(alum1.getApellido()) );
		lista.forEach(System.out::println);
		System.out.println("------------");
		
	}

}
