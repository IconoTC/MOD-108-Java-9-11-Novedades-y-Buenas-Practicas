module com.viewnext.ejercicio4 {
	requires java.net.http;
	requires org.json;
}