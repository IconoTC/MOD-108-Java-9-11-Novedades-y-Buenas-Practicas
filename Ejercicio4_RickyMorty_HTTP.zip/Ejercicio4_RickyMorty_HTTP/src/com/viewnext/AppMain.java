package com.viewnext;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

import org.json.JSONArray;
import org.json.JSONObject;

public class AppMain {

	public static void main(String[] args) throws Exception {
		String url = "https://rickandmortyapi.com/api/character";
		
		// Preparar la peticion
		URI uri = new URI(url);
		HttpRequest request = HttpRequest.newBuilder(uri).GET().build();
		
		// Crear el contenedor cliente
		HttpClient cliente = HttpClient.newHttpClient();
		
		// Enviar la peticion
		HttpResponse<String> respuesta = cliente.send(request, HttpResponse.BodyHandlers.ofString());
		
		// Procesar la respuesta
		JSONObject jsonObject = new JSONObject(respuesta.body());
		JSONArray jsonArray = new JSONArray(jsonObject.get("results").toString());
		
		for(Object obj : jsonArray) {
			JSONObject json = new JSONObject(obj.toString());
			System.out.println("Nombre: " + json.getString("name"));
			System.out.println("Estado: " + json.getString("status"));
			System.out.println("Especie: " + json.getString("species"));
			System.out.println("--------------------------");
		}
		
		

	}

}
