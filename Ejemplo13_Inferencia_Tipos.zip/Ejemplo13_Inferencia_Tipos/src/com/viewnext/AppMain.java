package com.viewnext;

import java.util.ArrayList;
import java.util.Arrays;

public class AppMain {
	
	// No podemos utilizar inferencia de tipos en variables globales
	//var numero = 7;

	public static void main(String[] args) {
		// La inferencia de tipos funciona solo en variables locales
		var prueba = 200;
		
		// No se puede aplicar a variables sin inicializar o con valor null
		//var saludo;
		//var adios = null;
		
		// Cuidado con los arrays
		var numeros = new int[] {1,2,3,4,5};
		//var numeros2 = {1,2,3,4,5};   ERROR
		
		// Colecciones
		var lista = new ArrayList<>(); // lista de objetos
		var lista2 = new ArrayList<Integer>();   // lista de enteros
		var lista3 = new ArrayList<>(Arrays.asList(1,2,3,4,5));  // lista de enteros
		var lista4 = new ArrayList<Integer>(Arrays.asList(1,2,3,4,5));  // lista de enteros
		
		// Crear un bucle para mostrar los numeros del 1 al 10 con inferencia
		for(var num=1; num <= 10; num++) {
			System.out.println(num);
		}
		
		// Crear un array de nombres y recorrelo con inferencia de tipos
		var nombres = new String[] {"Juan", "Maria", "Pedro", "Luis", "Sara"};
		for(var item: nombres) {
			System.out.println(item);
		}


	}

}
