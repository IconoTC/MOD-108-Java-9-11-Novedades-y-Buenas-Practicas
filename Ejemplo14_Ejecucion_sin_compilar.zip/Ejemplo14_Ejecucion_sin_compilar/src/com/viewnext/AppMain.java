package com.viewnext;

public class AppMain {

	public static void main(String[] args) {
		
		// java /Users/anaisabelvegascaceres/Desktop/Novedades9_11_ViewNext_13_Noviembre/Ejemplo14_Ejecucion_sin_compilar/src/com/viewnext/AppMain.java
		System.out.println("Esto es una prueba de ejecutar codigo sin compilar");
		
		// OJO!! No funciona si hay que cargar otras clases.
		// p.e. crear una instancia de Alumno y mostrarla por consola

	}

}
