module com.viewnext.consumidor {
	
	requires com.viewnext.servicio;
	uses com.viewnext.interfaz.ItfzCalculadora;
}