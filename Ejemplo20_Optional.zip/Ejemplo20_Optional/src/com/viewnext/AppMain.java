package com.viewnext;

import java.util.Optional;

import com.viewnext.models.Producto;
import com.viewnext.persistence.ProductosDAO;

public class AppMain {

	public static void main(String[] args) {
		
		ProductosDAO dao = new ProductosDAO();
		
		// Buscar un producto que existe
		System.out.println(dao.buscarProducto(3).get());
		
		// Buscar un producto que NO EXISTE
		// java.util.NoSuchElementException: No value present
		//System.out.println(dao.buscarProducto(344432212).get());
		
		// Primera forma de evitar excepciones
		System.out.println(dao.buscarProducto(344432212).orElse(new Producto()));
		
		// Segunda forma
		Optional<Producto> optionalProd = dao.buscarProducto(4);
		if (optionalProd.isPresent()) {
			System.out.println(optionalProd.get());
		} else {
			System.out.println("Ese producto no existe");
		}
		

	}

}
