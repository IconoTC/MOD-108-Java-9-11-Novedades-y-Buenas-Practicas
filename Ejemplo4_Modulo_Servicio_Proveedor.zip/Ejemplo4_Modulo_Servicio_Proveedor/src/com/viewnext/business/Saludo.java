package com.viewnext.business;

import com.viewnext.interfaz.ItfzSaludo;

public class Saludo implements ItfzSaludo{

	@Override
	public String saludar() {
		// TODO Auto-generated method stub
		return "Bienvenidos a mi prueba de servicios con modulos";
	}

}
