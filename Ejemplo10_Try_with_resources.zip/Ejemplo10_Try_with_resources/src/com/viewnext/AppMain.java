package com.viewnext;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class AppMain {

	public static void main(String[] args) throws SQLException {
		
		// Antes
		Connection con = null;
		try {
			con = DriverManager.getConnection("", "", "");
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		// A partir de Java 9. El try con recusos no necesita de bloque finally
		// Version 1
		try (Connection con2 = DriverManager.getConnection("", "", "")){
			// Cuando llega al final del try sin ninguna excepcion,
			// la conexion se cierra de forma automatica
		} catch(Exception e) {
			// Si se produce alguna excepcion tambien se cierra aqui la conexion
		}
		
		// Version 2
		Connection con3 = DriverManager.getConnection("", "", "");
		try (con3){
			// Cuando llega al final del try sin ninguna excepcion,
			// la conexion se cierra de forma automatica
		} catch(Exception e) {
			// Si se produce alguna excepcion tambien se cierra aqui la conexion
		}
	}

}




